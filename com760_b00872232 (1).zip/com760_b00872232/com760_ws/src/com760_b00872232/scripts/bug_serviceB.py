#! /usr/bin/env python

from com760_b00872232.srv import *
import rospy


def bug2_clbk(request):
    return B00873436SetBugBehaviourStatusResponse('home')


def BugBehaviour():
    print('creating')

    rospy.init_node("b00872232SetBugBehaviour")
    rospy.Service("b00872232SetBugBehaviour", b00872232SetBugBehaviour, bug2_clbk)

    print('created')
    rospy.spin()


if __name__ == "__main__":
    BugBehaviour()
