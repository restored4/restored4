#!/usr/bin/env python
import rospy
import math
import tf2_ros
from random import randint
import tf
import turtlesim.srv
import geometry_msgs.msg
import random
from turtlesim.srv import TeleportAbsolute
from geometry_msgs.msg import *
from turtlesim.msg import *
from turtlesim.srv import *
from std_msgs.msg import String
from com760_b00872232.msg import b00872232LeaderMessage
from math import atan2, pi, sqrt, pow
from com760_b00872232.srv import b00872232ServicePID

leader_x = 5.5
leader_y = 5.5
ps_x = 11
ps_y = 11
leader_theta = 1
tolerance = 0.1 
in_formation = False

def callback(data):
    instruction = data.instructionID
    message = data.message
    print(instruction,message)

def leader_pose(data):
       global leader_x, leader_y, leader_theta
       leader_x =  data.x
       leader_y =  data.y
       leader_theta = data.theta

#Gets the leader Pose, this is a subscriber call back
def runner_pose(data):
    global ps_x, ps_y
    ps_x = data.x
    ps_y = data.y


#Get the distance between two points on a plane.
def get_distance(x1, y1, x2, y2):
    return sqrt(pow((x2-x1),2) + pow((y2-y1),2))


def linear_vel(constant=1.0):
    global leader_x, leader_y, ps_x, ps_y
    return constant * get_distance(leader_x, leader_y, ps_x, ps_y)

def steering_angle():
    global leader_x, leader_y, ps_x, ps_y
    return atan2(ps_y - leader_y, ps_x - leader_x)

def angular_vel(constant=4):
    global leader_theta
    return constant * (steering_angle() - leader_theta)

def back_to_formation():
    global ps_x, ps_y
    ps_x = 5.5
    ps_y = 5.5
    

if __name__ == '__main__':

    rospy.init_node('turtle_tf2_listener')
    
    tfBuffer = tf2_ros.Buffer()
    listener = tf2_ros.TransformListener(tfBuffer)


    rospy.wait_for_service('spawn')
    spawner = rospy.ServiceProxy('spawn', turtlesim.srv.Spawn)
    #turtle_name = rospy.get_param('turtle', 'turtle2')
    spawner(random.randint(1,10), random.randint(1,10), 0, "followerA")
    spawner(random.randint(1,10), random.randint(1,10), 0, "followerB")


    turtle_vel = rospy.Publisher('followerA/cmd_vel', Twist, queue_size=1)
    turtle_vel2 = rospy.Publisher('followerB/cmd_vel', Twist, queue_size=1)


    rospy.wait_for_service("/followerA/set_pen")
    setPen = rospy.ServiceProxy("/followerA/set_pen", SetPen)
    setPen(255, 255, 225, 3, 0) #followerA moves with color white

    rospy.wait_for_service("/followerB/set_pen")
    setPen = rospy.ServiceProxy("/followerB/set_pen", SetPen)
    setPen(255, 255, 225, 3, 0) #followerB moves with color white


    pub = rospy.Publisher('turtle1/cmd_vel', Twist, queue_size=10)
   
  
    #pub.publish(vel_msg)
    custom_pub = rospy.Publisher("com760_b00872232", b00872232LeaderMessage, queue_size=10)  
    custom_msg = b00872232LeaderMessage()


    rospy.Subscriber("com760_b00872232", b00872232LeaderMessage, callback)
    rospy.Subscriber("turtle1/pose", Pose, leader_pose)
    msg = geometry_msgs.msg.Twist()

    rate = rospy.Rate(10.0)
    while not rospy.is_shutdown():
        
        custom_msg.instructionID = 0
        custom_msg.message = "GO"
        custom_pub.publish(custom_msg)
        try:
            trans = tfBuffer.lookup_transform("followerA", 'carrot1', rospy.Time())
            trans2 = tfBuffer.lookup_transform("followerB", 'carrot2', rospy.Time())
        except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
            rate.sleep()
            continue

        

        msg.angular.z = 4 * math.atan2(trans.transform.translation.y, trans.transform.translation.x)
        msg.linear.x = 0.5 * math.sqrt(trans.transform.translation.x ** 2 + trans.transform.translation.y ** 2)

        turtle_vel.publish(msg)

        msg.angular.z = 4 * math.atan2(trans2.transform.translation.y, trans2.transform.translation.x)
        msg.linear.x = 0.5 * math.sqrt(trans2.transform.translation.x ** 2 + trans2.transform.translation.y ** 2)

        

        turtle_vel2.publish(msg)

        
        if trans.transform.translation.y == 0 and trans.transform.translation.x == 0 and trans2.transform.translation.y == 0 and trans2.transform.translation.x == 0:
                in_formation = True
               
                   
              
        if in_formation:
             distance = get_distance(leader_x, leader_y, ps_x, ps_y)
                  
            
             if distance <= tolerance:
                  back_to_formation()
             else:
                  motion = geometry_msgs.msg.Twist()
                  motion.linear.x = linear_vel()
		  motion.angular.z = angular_vel()
			
	          pub.publish(motion)

             in_formation = True



        rate.sleep()
