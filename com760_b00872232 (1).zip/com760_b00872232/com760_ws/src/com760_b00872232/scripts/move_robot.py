#!/usr/bin/env python

import rospy
import random
from geometry_msgs.msg import Twist

def move_robot():
	rospy.init_node('move_robot', anonymous = True)
	pub = rospy.Publisher('com760Bot/cmd_vel', Twist, queue_size=10)
	rate = rospy.Rate(10) # 10hz

	vel_msg = Twist()
	vel_msg.linear.x = 1.0
	vel_msg.angular.z = 0.5
    
	
	while not rospy.is_shutdown():
		rospy.loginfo(vel_msg)
		pub.publish(vel_msg)
		rate.sleep()

if __name__ == '__main__':
	try:
		move_robot()
	except rospy.ROSInterruptException:
		pass
