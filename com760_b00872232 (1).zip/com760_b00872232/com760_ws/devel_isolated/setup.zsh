#!/usr/bin/env zsh
# generated from catkin.builder Python module

. "/home/amos/com760_ws/devel_isolated/learning_tf2/setup.zsh"
