#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
from turtlesim.srv import TeleportAbsolute
import time


sleep_time = rospy.get_param('~sleep', 51.5)
time.sleep(sleep_time)




if __name__ == '__main__':
    try:
        # Initialize ROS node
        rospy.init_node('teleport_turtlesim_robots', anonymous=True)

        # Create publishers to send commands to teleport the robots
        followerA_pub = rospy.Publisher('/followerA/cmd_vel', Twist, queue_size=10)
        followerB_pub = rospy.Publisher('/followerB/cmd_vel', Twist, queue_size=10)
        leader_pub = rospy.Publisher('/leader/cmd_vel', Twist, queue_size=10)

        stop_cmd = Twist()
        followerA_pub.publish(stop_cmd)
        followerB_pub.publish(stop_cmd)
        leader_pub.publish(stop_cmd)

        rospy.wait_for_service('/followerA/teleport_absolute')
        rospy.wait_for_service('/followerB/teleport_absolute')
        rospy.wait_for_service('/leader/teleport_absolute')

        # Create service proxies to teleport the turtles to the desired positions
        teleportA = rospy.ServiceProxy('/followerA/teleport_absolute', TeleportAbsolute)
        teleportB = rospy.ServiceProxy('/followerB/teleport_absolute', TeleportAbsolute)
        teleport_leader = rospy.ServiceProxy('/leader/teleport_absolute', TeleportAbsolute)
        
        teleportA(5.54, 3.54, 1.5708)
        teleportB(5.54, 1.54, 1.5708)
        teleport_leader(5.5, 5.5, 1.5708)

        rospy.sleep(1)

    except rospy.ROSInterruptException:
        pass

