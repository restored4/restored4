# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "${prefix}/include".split(';') if "${prefix}/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;std_msgs;message_runtime".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lcom760_tutorials".split(';') if "-lcom760_tutorials" != "" else []
PROJECT_NAME = "com760_tutorials"
PROJECT_SPACE_DIR = "/home/amos/com760_ws/install_isolated"
PROJECT_VERSION = "0.0.0"
