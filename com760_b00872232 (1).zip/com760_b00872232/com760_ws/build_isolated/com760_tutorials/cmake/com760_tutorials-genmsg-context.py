# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/amos/com760_ws/src/com760_tutorials/msg/Num.msg"
services_str = "/home/amos/com760_ws/src/com760_tutorials/srv/AddTwoInts.srv"
pkg_name = "com760_tutorials"
dependencies_str = "std_msgs"
langs = "gencpp;geneus;genlisp;gennodejs;genpy"
dep_include_paths_str = "com760_tutorials;/home/amos/com760_ws/src/com760_tutorials/msg;std_msgs;/opt/ros/kinetic/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python2"
package_has_static_sources = '' == 'TRUE'
genmsg_check_deps_script = "/opt/ros/kinetic/share/genmsg/cmake/../../../lib/genmsg/genmsg_check_deps.py"
