#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/amos/com760_ws/devel_isolated/com760_b00872232:$CMAKE_PREFIX_PATH"
export PWD='/home/amos/com760_ws/build_isolated/com760_b00872232'
export ROSLISP_PACKAGE_DIRECTORIES="/home/amos/com760_ws/devel_isolated/com760_b00872232/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/amos/com760_ws/src/com760_b00872232:$ROS_PACKAGE_PATH"