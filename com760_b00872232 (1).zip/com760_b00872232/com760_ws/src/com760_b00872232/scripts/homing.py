#! /usr/bin/env python

from assignment.srv import *
import rospy


def home_clbk(request):
    return b00872232HomingSignalResp('points  ' + str(request.dest_x) + ' '+str(request.dest_y))


def callbackBug(request):
    return b00872232SetBugBehaviourResp('home')


def home():

    rospy.init_node('b00872232HomingSignal')
    rospy.Service('b00872232HomingSignal', b00872232HomingSignal, home_clbk)

    rospy.spin()


def BugBehaviour():
    rospy.init_node('service_B')
    rospy.Service('service_B', b00872232SetBugBehaviour, callbackBug)


if __name__ == "__main__":
    home()
