// Auto-generated. Do not edit!

// (in-package com760_b00872232.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class b00872232HomingSignalRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.flag = null;
      this.des_x = null;
      this.des_y = null;
    }
    else {
      if (initObj.hasOwnProperty('flag')) {
        this.flag = initObj.flag
      }
      else {
        this.flag = false;
      }
      if (initObj.hasOwnProperty('des_x')) {
        this.des_x = initObj.des_x
      }
      else {
        this.des_x = 0.0;
      }
      if (initObj.hasOwnProperty('des_y')) {
        this.des_y = initObj.des_y
      }
      else {
        this.des_y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type b00872232HomingSignalRequest
    // Serialize message field [flag]
    bufferOffset = _serializer.bool(obj.flag, buffer, bufferOffset);
    // Serialize message field [des_x]
    bufferOffset = _serializer.float32(obj.des_x, buffer, bufferOffset);
    // Serialize message field [des_y]
    bufferOffset = _serializer.float32(obj.des_y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type b00872232HomingSignalRequest
    let len;
    let data = new b00872232HomingSignalRequest(null);
    // Deserialize message field [flag]
    data.flag = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [des_x]
    data.des_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [des_y]
    data.des_y = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 9;
  }

  static datatype() {
    // Returns string type for a service object
    return 'com760_b00872232/b00872232HomingSignalRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '954329a42c7f296d77934d2e8c6e3c5c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool flag
    float32 des_x
    float32 des_y
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new b00872232HomingSignalRequest(null);
    if (msg.flag !== undefined) {
      resolved.flag = msg.flag;
    }
    else {
      resolved.flag = false
    }

    if (msg.des_x !== undefined) {
      resolved.des_x = msg.des_x;
    }
    else {
      resolved.des_x = 0.0
    }

    if (msg.des_y !== undefined) {
      resolved.des_y = msg.des_y;
    }
    else {
      resolved.des_y = 0.0
    }

    return resolved;
    }
};

class b00872232HomingSignalResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.message = null;
    }
    else {
      if (initObj.hasOwnProperty('message')) {
        this.message = initObj.message
      }
      else {
        this.message = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type b00872232HomingSignalResponse
    // Serialize message field [message]
    bufferOffset = _serializer.string(obj.message, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type b00872232HomingSignalResponse
    let len;
    let data = new b00872232HomingSignalResponse(null);
    // Deserialize message field [message]
    data.message = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.message.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'com760_b00872232/b00872232HomingSignalResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5f003d6bcc824cbd51361d66d8e4f76c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string message
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new b00872232HomingSignalResponse(null);
    if (msg.message !== undefined) {
      resolved.message = msg.message;
    }
    else {
      resolved.message = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: b00872232HomingSignalRequest,
  Response: b00872232HomingSignalResponse,
  md5sum() { return '0c0bc8c7b3e6d49c504b3dd6bce9a912'; },
  datatype() { return 'com760_b00872232/b00872232HomingSignal'; }
};
